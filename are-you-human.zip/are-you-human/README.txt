# Are You Human?

A pixel-art CAPTCHA game. Open index.html in a browser. Needs internet only for the Press Start 2P font (falls back to monospace offline).
